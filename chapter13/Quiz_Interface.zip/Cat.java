package chapter13.Quiz_Interface;

public class Cat implements Soundable{

	@Override
	public String sound() {
		return "야옹";
	}

}
