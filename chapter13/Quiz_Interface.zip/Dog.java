package chapter13.Quiz_Interface;

public class Dog implements Soundable{

	public String sound() {
		return "멍멍";
	}
	
}
