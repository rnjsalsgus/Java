package chapter13.Quiz_Interface;

public interface Soundable {
	String sound();
}
